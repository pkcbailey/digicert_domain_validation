##########################
# Script by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Any questions you can reach out to Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Optimized version for improved performance
# Infoblox.com
##########################

import sys
import time
import os

# Import optimized modules
import scripts.helper as h
from scripts.Resolve_Domains import main as resolve_domains
from scripts.Sinkholing_Out import main as sinkholing_out  
from scripts.Finalized_Results import main as finalized_results

def print_banner():
    """Display application banner"""
    print("="*60)
    print("  INFOBLOX DNS RESOLUTION TESTING TOOL")
    print("  Optimized Version")
    print("="*60)

def validate_environment():
    """Check if required directories and files exist"""
    files_dir = os.path.join(os.getcwd(), 'files')
    
    if not os.path.exists(files_dir):
        print(f"Creating 'files' directory...")
        os.makedirs(files_dir)
        print("Please add .txt files containing domain lists to the 'files' directory.")
        return False
    
    # Check for domain files
    txt_files = [f for f in os.listdir(files_dir) if f.endswith('.txt')]
    if not txt_files:
        print("No .txt domain files found in 'files' directory.")
        print("Please add domain list files (.txt format) to continue.")
        return False
    
    return True

def main():
    """Main execution function with error handling and progress tracking"""
    
    print_banner()
    
    # Validate environment
    if not validate_environment():
        input("\nPress Enter to exit...")
        return
    
    try:
        start_time = time.time()
        
        print("\n" + "="*60)
        print("STEP 1: CONFIGURATION")
        print("="*60)
        
        # Get list of available input files
        input_files = h.list_files("files")
        if not input_files:
            print("No domain files available. Exiting.")
            return
        
        # User configuration
        sinkhole = h.sinkholes()
        timeout = h.ask_for_timeout()
        files = h.main(input_files)
        amount = h.ask_for_amount()
        
        # Configuration summary
        print(f"\n" + "="*60)
        print("CONFIGURATION SUMMARY")
        print("="*60)
        print(f"Files to process: {len(files)}")
        for i, f in enumerate(files, 1):
            print(f"  {i}. {os.path.basename(f)}")
        print(f"Domains per file: {amount:,}")
        print(f"DNS timeout: {timeout}s")
        print(f"Custom sinkholes: {len(sinkhole)}")
        print("="*60)
        
        # Confirm before proceeding
        if amount > 100 or len(files) > 1:
            confirm = input("\nProceed with testing? (y/n): ").lower().strip()
            if confirm not in ['y', 'yes']:
                print("Testing cancelled.")
                return
        
        print(f"\n" + "="*60)
        print("STEP 2: DNS RESOLUTION TESTING")
        print("="*60)
        
        # Begin DNS resolution process
        resolve_start = time.time()
        resolve_domains(files, sinkhole, amount, timeout)
        resolve_end = time.time()
        
        print(f"\n✓ DNS resolution completed in {resolve_end - resolve_start:.1f} seconds")
        
        print(f"\n" + "="*60)
        print("STEP 3: SINKHOLE DETECTION")
        print("="*60)
        
        # Process sinkhole detection
        sinkhole_start = time.time()
        sinkholing_out(sinkhole)
        sinkhole_end = time.time()
        
        print(f"\n✓ Sinkhole detection completed in {sinkhole_end - sinkhole_start:.1f} seconds")
        
        print(f"\n" + "="*60)
        print("STEP 4: GENERATING FINAL STATISTICS")  
        print("="*60)
        
        # Generate final statistics
        stats_start = time.time()
        finalized_results()
        stats_end = time.time()
        
        print(f"\n✓ Statistics generation completed in {stats_end - stats_start:.1f} seconds")
        
        # Final summary
        total_time = time.time() - start_time
        
        print(f"\n" + "="*60)
        print("TESTING COMPLETED SUCCESSFULLY!")
        print("="*60)
        print(f"Total execution time: {total_time:.1f} seconds")
        print(f"Average time per domain: {total_time / (amount * len(files)):.3f} seconds")
        
        # Show output files
        results_dir = os.path.join(os.getcwd(), 'results')
        if os.path.exists(results_dir):
            result_files = [f for f in os.listdir(results_dir) if f.endswith('.csv')]
            print(f"\nOutput files generated ({len(result_files)} files):")
            for f in sorted(result_files):
                print(f"  - results/{f}")
        
        # Show statistics file
        stats_files = [f for f in os.listdir('.') if f.startswith('statistics') and f.endswith('.csv')]
        if stats_files:
            print(f"\nStatistics file: {stats_files[-1]}")  # Show most recent
        
        print("="*60)
        
    except KeyboardInterrupt:
        print("\n\nTesting interrupted by user.")
        print("Partial results may be available in the 'results' directory.")
        
    except Exception as e:
        print(f"\nError during execution: {e}")
        print("Please check your configuration and try again.")
        
        # Print traceback for debugging
        import traceback
        print("\nDetailed error information:")
        traceback.print_exc()
        
    finally:
        input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
