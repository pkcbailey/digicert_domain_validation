##########################
# Script by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Optimized version
# Infoblox.com
##########################

import os

def list_files(folder_name):
    """Gathers names of the files in the specified folder"""
    try:
        folder_path = os.path.join(os.getcwd(), folder_name)
        if not os.path.exists(folder_path):
            print(f"Creating {folder_name} directory...")
            os.makedirs(folder_path)
            return []
        
        file_list = os.listdir(folder_path)
        files_only = [
            os.path.join(folder_path, f) 
            for f in file_list 
            if os.path.isfile(os.path.join(folder_path, f)) and f.endswith(".txt")
        ]
        
        if not files_only:
            print(f"No .txt files found in {folder_name} directory.")
        
        return files_only
    except Exception as e:
        print(f"Error accessing folder '{folder_name}': {e}")
        return []

def ask_for_timeout():
    """Ask user for timeout with improved validation and suggestions"""
    print("\nTimeout Configuration:")
    print("- Low timeout (1-3s): Faster but may miss slow DNS servers")
    print("- Medium timeout (5-10s): Balanced approach (recommended)")  
    print("- High timeout (15-30s): Slower but more thorough")
    
    while True:
        user_input = input("\nEnter timeout in seconds (press Enter for default 5s): ").strip()
        
        if user_input == "":
            print("Using default timeout of 5 seconds")
            return 5
        
        try:
            timeout = int(user_input)
            if 1 <= timeout <= 60:
                if timeout > 30:
                    confirm = input(f"Warning: {timeout}s timeout is quite high. Continue? (y/n): ").lower()
                    if confirm not in ['y', 'yes']:
                        continue
                return timeout
            else:
                print("Please provide a number between 1-60 seconds")
        except ValueError:
            print("Please enter a valid number")

def main(input_files):
    """File selection with improved interface"""
    if not input_files:
        print("No input files found. Please add .txt files to the 'files' directory.")
        return []
    
    print("\nAvailable test files:")
    print("-" * 40)
    
    for i, file_path in enumerate(input_files, 1):
        filename = os.path.basename(file_path)
        try:
            # Count lines in file for user info
            with open(file_path, 'r') as f:
                line_count = sum(1 for line in f if line.strip())
            print(f"{i:2d}. {filename} ({line_count:,} domains)")
        except:
            print(f"{i:2d}. {filename} (unable to count domains)")
    
    print("-" * 40)
    
    while True:
        user_input = input(f"\nSelect file number (1-{len(input_files)}) or press Enter for all files: ").strip()
        
        if user_input == "":
            print(f"Selected: All {len(input_files)} files")
            return input_files
        
        try:
            choice = int(user_input)
            if 1 <= choice <= len(input_files):
                selected_file = input_files[choice - 1]
                print(f"Selected: {os.path.basename(selected_file)}")
                return [selected_file]
            else:
                print(f"Please enter a number between 1 and {len(input_files)}")
        except ValueError:
            print("Please enter a valid number or press Enter")

def sinkholes():
    """Collect sinkhole IPs with improved validation"""
    all_sinkholes = []
    
    print("\nSinkhole Configuration:")
    print("Enter any custom sinkhole IP addresses (one per line)")
    print("These will be treated as blocked/malicious IPs")
    print("Press Enter on empty line when done")
    print("-" * 40)
    
    while True:
        sinkhole = input("Sinkhole IP (or Enter to finish): ").strip()
        
        if sinkhole == "":
            if all_sinkholes:
                print(f"\nConfigured {len(all_sinkholes)} custom sinkhole(s):")
                for i, ip in enumerate(all_sinkholes, 1):
                    print(f"  {i}. {ip}")
            else:
                print("No custom sinkholes configured (using defaults only)")
            return all_sinkholes
        
        # Basic IP validation
        if is_valid_ip(sinkhole):
            if sinkhole not in all_sinkholes:
                all_sinkholes.append(sinkhole)
                print(f"Added: {sinkhole}")
            else:
                print(f"Already added: {sinkhole}")
        else:
            print(f"Invalid IP format: {sinkhole}. Please enter a valid IP address.")

def is_valid_ip(ip):
    """Basic IP address validation"""
    try:
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        for part in parts:
            if not (0 <= int(part) <= 255):
                return False
        return True
    except (ValueError, AttributeError):
        return False

def ask_for_amount():
    """Ask for domain count with better guidance"""
    print("\nDomain Testing Amount:")
    print("- Small test (1-100): Quick validation")
    print("- Medium test (100-500): Balanced testing") 
    print("- Large test (500-1000): Comprehensive testing")
    
    while True:
        user_input = input("\nHow many domains to test (1-1000): ").strip()
        
        try:
            amount = int(user_input)
            if 1 <= amount <= 1000:
                # Provide time estimates
                estimated_time = estimate_test_time(amount)
                print(f"Testing {amount:,} domains (estimated time: {estimated_time})")
                
                if amount > 500:
                    confirm = input("Large test selected. Continue? (y/n): ").lower()
                    if confirm not in ['y', 'yes']:
                        continue
                
                return amount
            else:
                print("Please enter a number between 1 and 1000")
        except ValueError:
            print("Please enter a valid number")

def estimate_test_time(domain_count):
    """Provide rough time estimates for user planning"""
    # Rough estimates based on parallel processing
    seconds_per_domain = 0.1  # With parallel processing
    total_seconds = domain_count * seconds_per_domain
    
    if total_seconds < 60:
        return f"{total_seconds:.0f} seconds"
    elif total_seconds < 3600:
        return f"{total_seconds/60:.1f} minutes"
    else:
        return f"{total_seconds/3600:.1f} hours"
