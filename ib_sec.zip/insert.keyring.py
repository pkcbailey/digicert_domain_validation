import keyring

# Define the service name and username
service_name = 'digicert'
username_api = 'digicert_api'
username_org = 'OrgID'

# Define the API key and organizational ID
api_key = 'BZQOHJPZQF64JHSO3DBE4IUXO64KIWY73DHBDNNHM5O3XJ5GFQFX4HXRJBRSXNS4OT6HKMR7F4PKZ3DUC'
org_id = '2090987'

# Store the API key and organizational ID in keyring
keyring.set_password(service_name, username_api, api_key)
keyring.set_password(service_name, username_org, org_id)
