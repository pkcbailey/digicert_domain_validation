##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Optimized for performance
# Infoblox.com
##########################
def main(input_files, sinkholes, amount, timeout_amount):
    import socket
    import csv
    import os
    import sys
    import random
    import json
    import concurrent.futures
    import threading
    from collections import defaultdict
    import time

    OK = "ALLOWED"
    NOT_OK = "BLOCKED"
    
    # Thread-safe progress tracking
    class ProgressTracker:
        def __init__(self, total):
            self.total = total
            self.completed = 0
            self.lock = threading.Lock()
        
        def update(self, increment=1):
            with self.lock:
                self.completed += increment
                return self.completed

    def resolve_domain_batch(domains_batch, sinkhole_ips, domain_information, timeout_num, progress_tracker, input_file_name):
        """Resolve a batch of domains with optimized DNS lookups"""
        results = []
        
        for domain in domains_batch:
            temp_obj = {
                "Name": domain.replace('.', '[.]'), 
                "IPAddress": "", 
                "Status": "", 
                "Property": "", 
                "Notes": "", 
                "ErrorMessage": ""
            }
            
            try:
                # Use getaddrinfo for better performance and IPv4/IPv6 support
                addr_info = socket.getaddrinfo(domain, None, socket.AF_INET, socket.SOCK_STREAM)
                ip_address = addr_info[0][4][0]
                
                temp_obj["IPAddress"] = ip_address
                temp_obj["Status"] = OK
                
                # Check if IP is in sinkhole list
                if ip_address in sinkhole_ips:
                    temp_obj["Status"] = NOT_OK
                    
            except (socket.gaierror, socket.timeout, OSError) as e:
                temp_obj["Status"] = NOT_OK
                temp_obj["ErrorMessage"] = str(e)
            
            # Add domain information if available
            domain_info = domain_information.get(domain, {})
            temp_obj["Property"] = domain_info.get('property', '')
            temp_obj["Notes"] = domain_info.get('notes', '')
            
            results.append(temp_obj)
            
            # Update progress
            completed = progress_tracker.update()
            if completed % 10 == 0:  # Update progress every 10 domains
                progress = completed / progress_tracker.total
                bar_length = 50
                block = int(progress * bar_length)
                sys.stdout.write(f"\r{input_file_name} Progress: [{'#' * block:<{bar_length}}] {int(progress * 100)}%")
                sys.stdout.flush()
        
        return results

    def random_sample(lst, num):
        """Get the user specified amount of domains out of the list of domains"""
        if num >= len(lst):
            return lst
        return random.sample(lst, num)

    def resolve_domains_parallel(domain_list, output_filename, sinkhole_ips, domain_information, timeout_num, max_workers=50):
        """Resolve domains using parallel processing"""
        
        input_file = output_filename[:-12]
        total_domains = len(domain_list)
        
        print(f"\n\nStarting to query {total_domains} domains from {os.path.basename(input_file)} using {max_workers} workers")
        
        # Set socket timeout globally
        socket.setdefaulttimeout(timeout_num)
        
        # Initialize progress tracker
        progress_tracker = ProgressTracker(total_domains)
        
        # Split domains into batches for better load distribution
        batch_size = max(1, total_domains // max_workers)
        domain_batches = [domain_list[i:i + batch_size] for i in range(0, total_domains, batch_size)]
        
        all_results = []
        resolved_domains = 0
        unresolved_domains = 0
        
        start_time = time.time()
        
        # Use ThreadPoolExecutor for parallel DNS resolution
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all batches
            future_to_batch = {
                executor.submit(
                    resolve_domain_batch, 
                    batch, 
                    sinkhole_ips, 
                    domain_information, 
                    timeout_num, 
                    progress_tracker,
                    os.path.basename(input_file)
                ): batch for batch in domain_batches
            }
            
            # Collect results as they complete
            for future in concurrent.futures.as_completed(future_to_batch):
                try:
                    batch_results = future.result()
                    all_results.extend(batch_results)
                except Exception as exc:
                    print(f'\nBatch generated an exception: {exc}')
        
        # Final progress update
        sys.stdout.write(f"\r{os.path.basename(input_file)} Progress: [{'#' * 50}] 100%")
        sys.stdout.flush()
        
        end_time = time.time()
        
        # Count resolved vs unresolved
        for result in all_results:
            if result["Status"] == OK:
                resolved_domains += 1
            else:
                unresolved_domains += 1
        
        print(f"\nCompleted {total_domains} domains from {os.path.basename(input_file)} in {end_time - start_time:.2f} seconds")
        
        # Write results to CSV
        with open(output_filename, 'w', newline='') as csvfile:
            fieldnames = ["Name", "IPAddress", "Status", "ErrorMessage", "Property", "Notes"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(all_results)
        
        # Print summary
        print(f"File: {output_filename}")
        print(f"Total Domains resolved: {resolved_domains}")
        print(f"Total Domains not resolved: {unresolved_domains}")
        print(f"Average time per domain: {(end_time - start_time) / total_domains:.3f} seconds")

    # Pre-compute sinkhole IPs set for faster lookups
    print("Preparing sinkhole IP list...")
    ip_base = "146.112."
    suffixes = range(1, 255)
    sinkhole_ips = set()
    
    # Add default sinkhole ranges
    sinkhole_ips.update([ip_base + "61." + str(i) for i in suffixes])
    sinkhole_ips.update([ip_base + "48." + str(i) for i in suffixes])
    
    # Add custom sinkholes
    sinkhole_ips.update(sinkholes)
    
    print(f"Loaded {len(sinkhole_ips)} sinkhole IP addresses")

    # Load domain information once
    json_file = os.path.join(os.path.join(os.getcwd(), 'files'), 'domain_info.json')
    domain_information = {}
    try:
        with open(json_file, 'r') as f:
            domain_information = json.load(f)
        print(f"Loaded domain information for {len(domain_information)} domains")
    except Exception as e:
        print(f"Could not load domain information: {e}. Results will not have Property or Notes")

    # Create results folder
    folder_path = os.path.join(os.getcwd(), 'results')
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    
    # Calculate optimal number of workers based on domain count and system
    base_workers = min(50, max(10, amount // 20))  # Adaptive worker count
    
    # Process each input file
    for domain_file in input_files:
        name = os.path.splitext(os.path.basename(domain_file))[0]
        output_file = name + "_results.csv"
        output_file = os.path.join(folder_path, output_file)
        
        try:
            # Load and sample domains
            with open(domain_file, 'r') as f:
                domains = [line.strip() for line in f if line.strip()]  # Remove empty lines
            
            print(f"Loaded {len(domains)} domains from {os.path.basename(domain_file)}")
            
            if not domains:
                print(f"Warning: No domains found in {domain_file}")
                continue
            
            # Sample the requested number of domains
            domains = random_sample(domains, amount)
            print(f"Testing {len(domains)} domains")
            
            # Resolve domains in parallel
            resolve_domains_parallel(domains, output_file, sinkhole_ips, domain_information, timeout_amount, base_workers)
            
            print(f"Results saved to '{output_file}'\n")
            
        except FileNotFoundError:
            print(f"Error: Domain file '{domain_file}' not found.")
            continue
        except Exception as e:
            print(f"Error processing {domain_file}: {e}")
            continue
