def get_label_ids():
    service = get_gmail_service()
    results = service.users().labels().list(userId='me').execute()
    labels = results.get('labels', [])

    if not labels:
        print('No labels found.')
        return {}
    else:
        label_ids = {}
        print('Labels:')
        for label in labels:
            print(f"{label['name']} (ID: {label['id']})")
            label_ids[label['name']] = label['id']
        return label_ids

if __name__ == '__main__':
    label_ids = get_label_ids()
    print("\nDictionary of Label Names to IDs:")
    print(label_ids)

