import subprocess

# URL to open
url = "https://chatgpt.com"

# Command to open Safari with the specified URL
subprocess.run(["open", "-a", "Safari", url])

