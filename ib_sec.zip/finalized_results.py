##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Optimized version
# Infoblox.com
##########################
import os
import csv
from collections import defaultdict
import time

def get_unique_file_name(file_path):
    """Generate unique filename if file already exists"""
    if not os.path.exists(file_path):
        return file_path
    
    file_name, file_ext = os.path.splitext(file_path)
    counter = 1
    while os.path.exists(file_path):
        file_path = f"{file_name}_{counter}{file_ext}"
        counter += 1
    
    return file_path

def process_csv_file(csv_file_path):
    """Process a single CSV file and return statistics"""
    OK = "ALLOWED"
    NOT_OK = "BLOCKED"
    
    try:
        stats = {OK: 0, NOT_OK: 0}
        
        with open(csv_file_path, 'r', newline='') as f:
            reader = csv.reader(f)
            header = next(reader, None)  # Skip header
            
            if not header:
                return None, "Empty file"
            
            # Find status column index (more robust than assuming column 2)
            status_col = 2  # Default
            for i, col_name in enumerate(header):
                if col_name.lower() in ['status', 'result']:
                    status_col = i
                    break
            
            for row_num, row in enumerate(reader, start=2):
                if len(row) <= status_col:
                    continue
                    
                status = row[status_col].strip()
                if status == OK:
                    stats[OK] += 1
                elif status == NOT_OK:
                    stats[NOT_OK] += 1
        
        total_rows = stats[OK] + stats[NOT_OK]
        
        if total_rows == 0:
            return None, "No valid data rows"
        
        # Calculate percentages (ensure proper division)
        percent_ok = (stats[OK] / total_rows) * 100 if total_rows > 0 else 0
        percent_not_ok = (stats[NOT_OK] / total_rows) * 100 if total_rows > 0 else 0
        
        # Validation: percentages should add up to 100% (within rounding error)
        total_percent = percent_ok + percent_not_ok
        if abs(total_percent - 100.0) > 0.1 and total_rows > 0:
            print(f"Warning: Percentages don't add up to 100% in {os.path.basename(csv_file_path)}")
            print(f"  Allowed: {stats[OK]}, Blocked: {stats[NOT_OK]}, Total: {total_rows}")
            print(f"  Calculated: {percent_ok:.2f}% + {percent_not_ok:.2f}% = {total_percent:.2f}%")
        
        return {
            "Allowed": stats[OK],
            "Blocked": stats[NOT_OK],
            "Total": total_rows,
            "Percentage Allowed": f"{percent_ok:.2f}%",
            "Percentage Blocked": f"{percent_not_ok:.2f}%"
        }, None
        
    except Exception as e:
        return None, str(e)

def main():
    """Generate comprehensive statistics from all CSV result files"""
    
    print("Generating final statistics...")
    start_time = time.time()
    
    # Get results directory
    try:
        results_directory = os.path.join(os.getcwd(), 'results')
        if not os.path.exists(results_directory):
            print("Error: Results directory does not exist.")
            return
    except Exception as e:
        print(f"Error accessing results directory: {e}")
        return
    
    # Find all CSV files (excluding existing statistics files)
    csv_files = []
    for filename in os.listdir(results_directory):
        if filename.endswith(".csv") and not filename.startswith("statistics"):
            csv_files.append(os.path.join(results_directory, filename))
    
    if not csv_files:
        print("No CSV result files found to process.")
        return
    
    print(f"Processing {len(csv_files)} result files...")
    
    # Process each file and collect statistics
    file_stats = {}
    total_allowed = 0
    total_blocked = 0
    total_domains = 0
    files_processed = 0
    errors = []
    
    for csv_file in csv_files:
        filename = os.path.basename(csv_file)
        stats, error = process_csv_file(csv_file)
        
        if error:
            errors.append(f"{filename}: {error}")
            print(f"⚠ {filename}: {error}")
        else:
            file_stats[filename] = stats
            total_allowed += stats["Allowed"]
            total_blocked += stats["Blocked"]
            total_domains += stats["Total"]
            files_processed += 1
            print(f"✓ {filename}: {stats['Total']} domains ({stats['Percentage Blocked']} blocked)")
    
    if not file_stats:
        print("No valid statistics could be generated.")
        return
    
    # Create detailed statistics CSV
    output_file = os.path.join(os.getcwd(), "statistics.csv")
    output_file = get_unique_file_name(output_file)
    
    try:
        with open(output_file, 'w', newline='') as f:
            writer = csv.writer(f)
            
            # Write header
            writer.writerow([
                "File", "Allowed", "Blocked", "Total", 
                "Percentage Allowed", "Percentage Blocked"
            ])
            
            # Write individual file statistics
            for filename, stats in file_stats.items():
                writer.writerow([
                    filename,
                    stats["Allowed"],
                    stats["Blocked"], 
                    stats["Total"],
                    stats["Percentage Allowed"],
                    stats["Percentage Blocked"]
                ])
            
            # Add summary row
            if len(file_stats) > 1:
                overall_percent_allowed = (total_allowed / total_domains) * 100 if total_domains > 0 else 0
                overall_percent_blocked = (total_blocked / total_domains) * 100 if total_domains > 0 else 0
                
                writer.writerow([])  # Empty row separator
                writer.writerow([
                    "OVERALL SUMMARY",
                    total_allowed,
                    total_blocked,
                    total_domains,
                    f"{overall_percent_allowed:.2f}%",
                    f"{overall_percent_blocked:.2f}%"
                ])
        
        end_time = time.time()
        
        # Print comprehensive summary
        print(f"\n{'='*60}")
        print("FINAL STATISTICS SUMMARY")
        print(f"{'='*60}")
        print(f"Files processed successfully: {files_processed}")
        print(f"Total domains tested: {total_domains:,}")
        print(f"Domains allowed: {total_allowed:,} ({(total_allowed/total_domains*100):.1f}%)")
        print(f"Domains blocked: {total_blocked:,} ({(total_blocked/total_domains*100):.1f}%)")
        print(f"Processing time: {end_time - start_time:.2f} seconds")
        print(f"Statistics saved to: {os.path.basename(output_file)}")
        
        if errors:
            print(f"\nWarnings/Errors:")
            for error in errors:
                print(f"  - {error}")
        
        print(f"{'='*60}")
        
        # Additional insights
        if len(file_stats) > 1:
            # Find files with highest/lowest block rates
            block_rates = [(filename, float(stats["Percentage Blocked"].rstrip('%'))) 
                          for filename, stats in file_stats.items()]
            block_rates.sort(key=lambda x: x[1])
            
            print("\nFile Analysis:")
            print(f"Lowest block rate: {block_rates[0][0]} ({block_rates[0][1]:.1f}%)")
            print(f"Highest block rate: {block_rates[-1][0]} ({block_rates[-1][1]:.1f}%)")
        
    except Exception as e:
        print(f"Error writing statistics file: {e}")
        return
    
    print(f"\nStatistics generation completed successfully!")
