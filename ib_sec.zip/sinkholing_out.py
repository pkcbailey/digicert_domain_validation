##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Optimized version
# Infoblox.com
##########################
def main(sinkholes):
    import os
    import csv
    import concurrent.futures
    import time

    OK = "ALLOWED"
    NOT_OK = "BLOCKED"

    try:
        actual_directory = os.path.join(os.getcwd(), 'results')
        if not os.path.exists(actual_directory):
            print("The 'results' folder does not exist.")
            return
    except Exception as e:
        print(f"An error occurred: {e}")
        return

    # Pre-compute all sinkhole IPs as sets for O(1) lookup
    print("Preparing sinkhole detection...")
    
    # Infoblox Redirect Addresses
    infoblox_redirects = {
        '3.215.231.251', '3.216.243.225', '35.168.95.233', 
        '54.173.31.46', '3.220.140.235'
    }

    # Base IP address ranges
    ip_base = "146.112."
    suffixes = range(1, 255)

    # Create comprehensive sinkhole IP set
    sinkhole_ips = set()
    
    # Add default sinkhole ranges
    sinkhole_ips.update([ip_base + "61." + str(i) for i in suffixes])
    sinkhole_ips.update([ip_base + "48." + str(i) for i in suffixes])
    
    # Add custom sinkholes
    sinkhole_ips.update(sinkholes)
    
    print(f"Configured {len(sinkhole_ips)} sinkhole IPs and {len(infoblox_redirects)} redirect IPs")

    def process_csv_file(csv_file_path):
        """Process a single CSV file for sinkhole detection"""
        changes_made = 0
        total_rows = 0
        
        try:
            # Read all rows
            with open(csv_file_path, 'r', newline='') as f:
                rows = list(csv.reader(f))
            
            if len(rows) <= 1:  # No data rows
                return csv_file_path, 0, 0
            
            total_rows = len(rows) - 1  # Exclude header
            
            # Process data rows (skip header)
            for row in rows[1:]:
                if len(row) < 3:  # Ensure row has enough columns
                    continue
                    
                ip_cell = row[1].strip()  # IPAddress column
                status = row[2].strip()   # Status column
                
                # Only process if currently marked as ALLOWED
                if status == OK and ip_cell:
                    # Split multiple IPs and check each one
                    ips_in_cell = [ip.strip() for ip in ip_cell.split(",")]
                    
                    # Check for sinkhole IPs
                    if any(ip in sinkhole_ips for ip in ips_in_cell):
                        row[2] = NOT_OK
                        changes_made += 1
                    
                    # Check for Infoblox redirect addresses
                    elif any(ip in infoblox_redirects for ip in ips_in_cell):
                        row[2] = NOT_OK
                        if len(row) > 3:  # Ensure ErrorMessage column exists
                            row[3] = "Infoblox Redirect Address"
                        changes_made += 1
            
            # Write changes back to file only if changes were made
            if changes_made > 0:
                with open(csv_file_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerows(rows)
            
            return os.path.basename(csv_file_path), changes_made, total_rows
            
        except Exception as e:
            print(f"Error processing {csv_file_path}: {e}")
            return os.path.basename(csv_file_path), 0, 0

    # Get all CSV files to process
    csv_files = []
    for filename in os.listdir(actual_directory):
        if filename.endswith(".csv") and not filename.startswith("statistics"):
            csv_files.append(os.path.join(actual_directory, filename))
    
    if not csv_files:
        print("No CSV files found to process.")
        return
    
    print(f"\nProcessing {len(csv_files)} CSV files for sinkhole detection...")
    start_time = time.time()
    
    total_changes = 0
    total_rows_processed = 0
    
    # Process files in parallel for better performance
    max_workers = min(len(csv_files), 4)  # Limit concurrent file operations
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit all files for processing
        future_to_file = {
            executor.submit(process_csv_file, csv_file): csv_file 
            for csv_file in csv_files
        }
        
        # Collect results
        for future in concurrent.futures.as_completed(future_to_file):
            filename, changes, rows = future.result()
            total_changes += changes
            total_rows_processed += rows
            
            if changes > 0:
                print(f"✓ {filename}: {changes} domains reclassified as blocked")
            else:
                print(f"- {filename}: No changes needed")
    
    end_time = time.time()
    
    # Summary
    print(f"\nSinkhole Detection Complete:")
    print(f"- Files processed: {len(csv_files)}")
    print(f"- Total rows checked: {total_rows_processed:,}")
    print(f"- Domains reclassified: {total_changes:,}")
    print(f"- Processing time: {end_time - start_time:.2f} seconds")
    
    if total_changes > 0:
        print(f"- {total_changes} domains were changed from ALLOWED to BLOCKED")
    else:
        print("- No sinkhole IPs detected in the results")
